<div class="sidebar">
	<ul class="xoxo">
		<?php  dynamic_sidebar( 'primary-widget-area' ); ?>
	</ul>
</div>
	
